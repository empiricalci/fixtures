# Fixtures

Just a collection of fixtures used for tests
